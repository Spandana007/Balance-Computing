package demo;
import java.util.ArrayList;

import demo.Search;
public class ValidationEngine 
{

	
		// TODO Auto-generated method stub
	public static void main(String args[])
	{
	  
	 
	ArrayList c1=new ArrayList();
	  System.out.println("Custdata is: "+Search.getCustdata(c1));
    }
	

}
