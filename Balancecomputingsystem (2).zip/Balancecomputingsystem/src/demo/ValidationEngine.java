package demo;

import java.util.ArrayList;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ValidationEngine
 */
public class ValidationEngine extends HttpServlet {
	private Search s;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidationEngine() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	 //*see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		
		//Search s=new Search();
		
		//s.getbaldata();
		 
		//int balance = s.getbaldata();
		//System.out.println(balance);
			
				// TODO Auto-generated method stub
			
			 
			
		   
			
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
         
		
		//s.getbaldata();
		//int balance = (int) request.getAttribute("totalbalance");
		//int balance = s.getbaldata();
		//System.out.println("Rs. "+balance);
		
		int balance = (int) request.getAttribute("totalbalance");
		System.out.println("End of Yr. balance is"+balance);
	}

	}


