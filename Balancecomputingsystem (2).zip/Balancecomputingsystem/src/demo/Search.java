package demo;


import java.io.*;




import javax.servlet.*;
import javax.servlet.http.*;
//import javax.sql.*;
import java.sql.*;
import java.util.*;

public class Search extends HttpServlet
{ 
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	 int totalbalance;
 
  @SuppressWarnings({ "rawtypes", "unchecked" })
   public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException 
   {
     response.setContentType("text/html");
     PrintWriter out = response.getWriter();
     Connection conn = null;
     String id=request.getParameter("id");
     PreparedStatement st;
     boolean found=false;
     //int totalbalance;
     try 
     {
	  //  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver").newInstance();
        String conURL = "jdbc:ucanaccess://C:/Users/688714/workspace/Balancecomputingsystem/WebContent/HTMLAccess.mdb";
		//String dbPath = application.getRealPath("/") + "HTMLAccess.mdb";
        
        
        

		conn = DriverManager.getConnection(conURL,"","");
		if(conn != null)
		{
			out.println("Database Connected.");
		} 
		else 
		{
			//out.println("Database Connect Failed.");
		}

   
      
         
        
        
        String query = "SELECT * FROM [CustomerData] WHERE ID='"+id+"'";
        
        System.out.println("query " + query);
        st = conn.prepareStatement(query);
        out.print("<table width=25% border=1>");

        out.print("<center><h1>Customer Records</h1></center>");

        ResultSet  rs = st.executeQuery();
        ResultSetMetaData rsmd=rs.getMetaData();
        
        
        
        
         if(rs.next())
         {
         out.print("<tr>");
         
         int balance=rs.getInt(3);
         int deposit=rs.getInt(4);
         int withdrawal=rs.getInt(5);
         int balance1=balance+deposit;
         //System.out.println(balance1);
         
         totalbalance=rs.getInt(3)+rs.getInt(4)-rs.getInt(5);
         
        // System.out.println(totalbalance);
         
        
         System.out.println("End of Yr balance of id "+ id +" is :"+totalbalance);
        
         out.print("<tr>");
         out.print("<td>"+rsmd.getColumnName(1)+"</td>");
         out.print("<td>"+"End of Yr. Balance"+"</td>");
         out.print("</tr>");
         out.print("<tr>");
         out.print("<td>"+id+"</td>");
         out.print("<td>"+totalbalance+"</td>");
         out.print("</tr>");
           
         
        out.print("</table>");
     }
        
         
        else
        {
        	out.print("No matching records found!!!");
        }
         rs.close();
         
        		 request.setAttribute("totalbalance",totalbalance);
                 //request.setAttribute("id", id);
        		 RequestDispatcher dis = request.getRequestDispatcher("ValidationEngine1");
        		 dis.forward(request,response);
      conn.close();
     // System.out.println("Disconnected from database");
      
     } 
       catch (Exception e) 
       {
        e.printStackTrace();
       }
   }
  /*public int sendbaldata(int totalbalance)
  {
  	//System.out.println(totalbalance);
	  
  	getbaldata();
  	return totalbalance;
  	
  }
  */
  
  public int getbaldata()
  {
	  int totbal1=totalbalance;
	  
	 // System.out.println(totbal1);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
	//  ValidationEngine v=new ValidationEngine();
	  return totbal1;
  }
  
    
   
    
 } 

