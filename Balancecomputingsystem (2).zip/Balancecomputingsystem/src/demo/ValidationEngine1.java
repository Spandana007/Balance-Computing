package demo;

public class ValidationEngine1 
{
	public static void main(String args[])
	{
		Search s=new Search();
		int balance=s.getbaldata();
		System.out.println(balance);
	}

}
